﻿namespace WinFormsApp1
{
    partial class ClubsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridViewClubs = new DataGridView();
            clubIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            cityDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            clubBindingSource = new BindingSource(components);
            buttonAdd = new Button();
            buttonEdit = new Button();
            buttonDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewClubs).BeginInit();
            ((System.ComponentModel.ISupportInitialize)clubBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewClubs
            // 
            dataGridViewClubs.AutoGenerateColumns = false;
            dataGridViewClubs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewClubs.Columns.AddRange(new DataGridViewColumn[] { clubIdDataGridViewTextBoxColumn, nameDataGridViewTextBoxColumn, cityDataGridViewTextBoxColumn });
            dataGridViewClubs.DataSource = clubBindingSource;
            dataGridViewClubs.Location = new Point(12, 12);
            dataGridViewClubs.Name = "dataGridViewClubs";
            dataGridViewClubs.Size = new Size(544, 150);
            dataGridViewClubs.TabIndex = 0;
            // 
            // clubIdDataGridViewTextBoxColumn
            // 
            clubIdDataGridViewTextBoxColumn.DataPropertyName = "ClubId";
            clubIdDataGridViewTextBoxColumn.HeaderText = "ClubId";
            clubIdDataGridViewTextBoxColumn.Name = "clubIdDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            nameDataGridViewTextBoxColumn.HeaderText = "Name";
            nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            nameDataGridViewTextBoxColumn.Width = 250;
            // 
            // cityDataGridViewTextBoxColumn
            // 
            cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            cityDataGridViewTextBoxColumn.HeaderText = "City";
            cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            cityDataGridViewTextBoxColumn.Width = 150;
            // 
            // clubBindingSource
            // 
            clubBindingSource.DataSource = typeof(Data.Models.Club);
            // 
            // buttonAdd
            // 
            buttonAdd.Font = new Font("Segoe UI", 14F);
            buttonAdd.Location = new Point(12, 168);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(170, 39);
            buttonAdd.TabIndex = 1;
            buttonAdd.Text = "Добави";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonEdit
            // 
            buttonEdit.Font = new Font("Segoe UI", 14F);
            buttonEdit.Location = new Point(200, 168);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(170, 39);
            buttonEdit.TabIndex = 2;
            buttonEdit.Text = "Редактирай";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.Font = new Font("Segoe UI", 14F);
            buttonDelete.Location = new Point(386, 168);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(170, 39);
            buttonDelete.TabIndex = 3;
            buttonDelete.Text = "Изтрий";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // ClubsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonDelete);
            Controls.Add(buttonEdit);
            Controls.Add(buttonAdd);
            Controls.Add(dataGridViewClubs);
            Name = "ClubsForm";
            Text = "ClubsForm";
            Load += ClubsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewClubs).EndInit();
            ((System.ComponentModel.ISupportInitialize)clubBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewClubs;
        private DataGridViewTextBoxColumn clubIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private BindingSource clubBindingSource;
        private Button buttonAdd;
        private Button buttonEdit;
        private Button buttonDelete;
    }
}