﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Storage;

namespace WinFormsApp1
{
    public partial class ClubsForm : Form
    {
        public ClubsForm()
        {
            InitializeComponent();
        }

        private void ClubsForm_Load(object sender, EventArgs e)
        {
            //TO-DO load clubs into grid
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //TO-DO add a club (maybe edit the grid a bit?)
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            //TO-DO edit a club
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //TO-DO delete a club
        }
    }
}
